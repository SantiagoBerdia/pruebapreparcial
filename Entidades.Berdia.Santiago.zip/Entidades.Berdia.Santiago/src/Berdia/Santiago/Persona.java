package Berdia.Santiago;

import java.util.Objects;


public class Persona {
    private String nombre;
    private String apellido;

    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }
    
    public static boolean sonIguales(Persona p1, Persona p2){
        return p1.equals(p2);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre,apellido);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Persona p)) {
            return false;
        }

        return nombre.equals(p.nombre) && apellido.equals(p.apellido);
    }
    
    public String getNombreApellido(){
        return nombre + "-" + apellido;
    }
}
