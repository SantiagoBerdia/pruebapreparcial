package Berdia.Santiago;

public enum TipoMoto {
    DEPORTIVA, SCOOTER, TOURING
}
