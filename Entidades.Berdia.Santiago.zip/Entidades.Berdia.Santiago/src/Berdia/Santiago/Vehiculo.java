package Berdia.Santiago;

import java.util.Objects;
import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author santi
 */

public abstract class Vehiculo {
    private Persona propietario;
    private String marca;
    private String modelo;
    private double precio;
    private int Kilometraje;
    private Random elegirkilometraje;
    private static int contadorVehiculo;
    private static final int INIT_CONTADOR = 50_000;
    private static int nextContador = INIT_CONTADOR;


    public Vehiculo(Persona propietario, String marca, String modelo, double precio) {
        this.propietario = propietario;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        elegirkilometraje = new Random();
        Kilometraje = elegirkilometraje.nextInt(0,300001);
        contadorVehiculo = getAndIncrementContador();
        
    }
   /**
    * hola soy docu
    * @return un numero
    */
    private int getAndIncrementContador(){
        return nextContador ++;
    }
    public double getPrecio() {
        return precio;
    }

    public int getKilometraje() {
        return Kilometraje;
    }
        
    public static boolean sonIguales(Vehiculo v1, Vehiculo v2){
        return v1.equals(v2);
    }

    
    private static String mostrarVehiculo(Vehiculo v){
        return v.toString();
    }
    
    
    
    
    
    
    
    
    
    @Override
    public int hashCode() {
        return Objects.hash(modelo,marca);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Vehiculo v)) {
            return false;
        }

        return modelo.equals(v.modelo) && marca.equals(v.marca);
}

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{" + "propietario=" + propietario + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + ", Kilometraje=" + Kilometraje + '}';
    }

    

}


