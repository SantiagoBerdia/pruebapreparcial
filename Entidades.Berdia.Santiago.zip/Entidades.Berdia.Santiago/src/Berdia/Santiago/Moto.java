package Berdia.Santiago;

import java.util.Objects;


public class Moto extends Vehiculo {
    private int cilindrada; 
    private TipoMoto tipoMoto;
    public Moto(Persona propietario, String marca, String modelo, double precio, int cilindrada, TipoMoto tipoMoto) {
        super(propietario, marca, modelo, precio);
        this.cilindrada = cilindrada;
        this.tipoMoto = tipoMoto;
    }
        
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(getClass() == obj.getClass())) {
            return false;
        }
        Moto m = (Moto) obj;
        return cilindrada == m.cilindrada;
}

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), cilindrada);
    }

    @Override
    public String toString() {
        return super.toString() + "tiene " + cilindrada;
    }
    
}
