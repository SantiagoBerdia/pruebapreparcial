package Berdia.Santiago;


public enum TipoAuto {
    SEDAN, HATCHBACK, SUV;

}
